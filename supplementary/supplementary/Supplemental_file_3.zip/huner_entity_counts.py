# encoding utf8

# These scripts are provided with the NER Pipeline Manuscript as supplmentary
# Kindly cite the article if you use this script
# Author: Rafsan Ahmed
# This script is used to count the number of entities in a single HUNER corpus

if __name__ == "__main__":

    huner_file = "path/to/huner/files/"
    
    with open(huner_file, encoding="utf8") as f:
        lines=f.readlines()
    
    d={}
    for line in lines:
        line=line.strip().split()
        if len(line)>2:
            print("err")
            
        if len(line)==2:
            if line[1] not in d:
                d[line[1]]=0
            d[line[1]]+=1

    print(d)