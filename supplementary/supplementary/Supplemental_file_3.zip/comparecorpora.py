#installation guidelines: $ pip install scattertext
#author: Sonja Aits, Lund University, Sweden; re-using some code from Scatterplot tutorial: https://github.com/JasonKessler/scattertext
#inputpaths should point to files in IOB2 format (tsv format with one word - TAB - entity tag on each line)
#input1_name and input2_name are the names to be displayed on the graph for each dataset


def scatter(inputpath1, inputpath2, input1_name, input2_name, outputpath):
    
    import scattertext as st
    import pandas as pd
    import spacy
    from pprint import pprint

    #extract IOB2 files into dataframes
    df = pd.DataFrame(columns = ['text', 'tag'])
    df1 = pd.read_csv(inputpath1, sep='\t', names= ['text', 'tag'], header = None)
    df2 = pd.read_csv(inputpath2, sep='\t', names= ['text', 'tag'], header = None)

    print(df1.shape)
    print(df2.shape)

    #convert text column to list and all list components to strings
    list1 = list(df1['text'])
    list1 = [str(i) for i in list1]
    list1 = [i.strip() for i in list1] #remove whitespace 
    list1 = [i for i in list1 if len(i) > 1] #remove items consisting of less than 2 characters


    list2 = list(df2['text'])
    list2 = [str(i) for i in list2]
    list2 = [x.strip() for x in list2] #remove whitespace
    list2 = [i for i in list2 if len(i) > 1] #remove items consisting of less than 2 characters

    #merge first 10000000 items on each list
    #this part of the code needs to be altered to take the entire lists instead, in batches of 1000000 items for each dataframe row
    df = pd.DataFrame()

    df.loc[0,'text'] = ' '.join(list1[0:1000000])
    df.loc[1,'text'] = ' '.join(list2[0:1000000])
    df.loc[0,'dataset'] = 'A'
    df.loc[1,'dataset'] = 'B'

    print(df)
    print()

    # split text into tokens on whitespace
    #this part of the code needs to be updated to perform splittng with spacy splitter instead

    print("PARSING")
    df['parse'] = df['text'].apply(st.whitespace_nlp_with_sentences)
    print(df)

    print("PARSING COMPLETE")
    print()

    # build corpus object
    nlp = spacy.load('en_core_web_sm')
    nlp.max_length = 7000000
    corpus = st.CorpusFromPandas(df, category_col='dataset', text_col='text',nlp=nlp).build()

    print("CORPUS COMPLETE")

    #print terms that distinguish corpus from general english
    print('TERMS MOST DIFFERENT FROM STANDARD ENGLISH')
    print(list(corpus.get_scaled_f_scores_vs_background().index[:10]))

    #print terms associated with collection 1
    print('TERMS ASSOCIATED WITH COLLECTION 1')
    term_freq_df = corpus.get_term_freq_df()
    term_freq_df['A Score'] = corpus.get_scaled_f_scores('A')
    pprint(list(term_freq_df.sort_values(by='A Score', ascending=False).index[:20]))

    #print terms associated with collection 2
    print('TERMS ASSOCIATED WITH COLLECTION 2')
    term_freq_df = corpus.get_term_freq_df()
    term_freq_df['B Score'] = corpus.get_scaled_f_scores('B')
    pprint(list(term_freq_df.sort_values(by='B Score', ascending=False).index[:20]))

    print('ANALYSIS COMPLETE - GENERATING PLOT')

    #visualize term associations in interactive html file
    html = st.produce_scattertext_explorer(corpus,category='A', category_name = input1_name, not_category_name = input2_name, width_in_pixels=1000)
    open(outputpath, 'wb').write(html.encode('utf-8'))

if __name__=="__main__":

    entity="species"

    input1 = f"/proj/berzelius-2021-21/users/rafsan/alvis/rafsan/biobert_main/pytorch-biobert/biobert-pytorch/datasets/NER/HunFlair_{entity}_all/train.tsv"
    input2 = f"/proj/berzelius-2021-21/users/rafsan/alvis/rafsan/biobert_main/pytorch-biobert/biobert-pytorch/datasets/NER/HunFlair_{entity}_all/test.tsv"
    input1_name = f"HunFlair_{entity}_train"
    input2_name = f"HunFlair_{entity}_test"
    output = f"/proj/berzelius-2021-21/users/rafsan/alvis/rafsan/biobert_main/pytorch-biobert/tests/res/compare_corpora_res/HunFlair_{entity}_train_test.html"
    


scatter(input1,input2, input1_name,input2_name, output)
