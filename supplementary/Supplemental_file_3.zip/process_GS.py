# encoding utf8

# These scripts are provided with the NER Pipeline Manuscript as supplmentary
# Kindly cite the article if you use this script
# Author: Rafsan Ahmed
# This script is used to preprocess the gold standard corpus into simplified Lund Covid-19 corpora


import pandas as pd
import os

if __name__ == "__main__":

    gs_file = "../../../gold_standard_paper/data/Gold_std.IOB2"
    outfile_path= "../data/gs_iob2_sonja/"
    
    # find entities
    '''entities  = set()

    with open(gs_file, encoding="utf8") as f:
        lines = f.readlines()
        
    for line in lines:
        line=line.strip().split(" ")
        entities.update([line[-1]])
    #         print(line)
    
    '''
    
    main_list_of_entities = ['B-Cell',
                        'B-Chemical',
                        'B-Disease_COVID-19',
                        'B-Disease_other',
                        'B-Protein',
                        'B-Species_human',
                        'B-Species_other',
                        'B-Symptom',
                        'B-Virus_SARS-CoV-2',
                        'B-Virus_family',
                        'B-Virus_other',
                        'I-Cell',
                        'I-Disease_COVID-19',
                        'I-Disease_other',
                        'I-Species_other',
                        'I-Symptom',
                        'I-Virus_SARS-CoV-2',
                        'I-Virus_family',
                        'I-Virus_other',
                        'O']

    list_of_virus_entities = ["B-Virus_SARS-CoV-2", "B-Virus_family", "I-Virus_SARS-CoV-2", "I-Virus_family",
                                         "B-Virus_other","I-Virus_other"]
    list_of_dis_entities=["B-Disease_COVID-19", "B-Disease_other", "I-Disease_COVID-19", "I-Disease_other"]
    list_of_symptoms = ["B-Symptom","I-Symptom"]
    list_of_species_entities = ['B-Species_human','B-Species_other','I-Species_human','I-Species_other']

    # dict of entity tags
    dict_lists={"disease":list_of_dis_entities,
    "species_with_virus":list_of_species_entities+list_of_virus_entities,
    "protein":["B-Protein", "I-Protein"]}
    

    for ent in sorted(dict_lists)[:]:
        os.makedirs(outfile_path+ent+"/", exist_ok=True)
        with open(outfile_path+ent+"/test.txt",  "w",encoding="utf8") as f:
            for line in lines:
                line=line.strip().split(" ")
                if line!=['']:
                    if line[-1][0] not in ["B", "I", "O"]:
                        print(line)
                    else:
                        if line[-1] in dict_lists[ent]:
                            f.write(f'{" ".join(line[:-1])}\t{line[-1][0]}\n')
                        else:
                            f.write(f'{" ".join(line[:-1])}\tO\n')
        
